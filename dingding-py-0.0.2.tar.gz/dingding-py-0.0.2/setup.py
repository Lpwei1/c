# -*- coding: utf-8 -*-
"""
Created on Mon Apr 19 15:32:40 2021

@author: weilp111
"""


from setuptools import setup
setup(name='dingding-py',
   version='0.0.2',
   description='this is a dingdingbot packages',
   author='Jruing',
   author_email='1099301992@qq.com',
   # packages=['Qingolddriver']
 
   )